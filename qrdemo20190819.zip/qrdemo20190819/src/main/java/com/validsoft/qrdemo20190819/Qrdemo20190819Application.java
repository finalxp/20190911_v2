package com.validsoft.qrdemo20190819;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qrdemo20190819Application {

	public static void main(String[] args) {
		SpringApplication.run(Qrdemo20190819Application.class, args);
	}

}
